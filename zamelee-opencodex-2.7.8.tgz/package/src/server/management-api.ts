import { readFileSync } from "node:fs";
import type { CatalogModel } from "../codex/catalog";
import { invalidateCodexModelsCache, nativeModelRows } from "../codex/catalog";
import {
  DEFAULT_SUBAGENT_MODELS,
  codexAutoStartEnabled,
  hasOwnProvider,
  isValidProviderName,
  providerBaseUrlConfigError,
  providerHeadersConfigError,
  saveConfig,
} from "../config";
import {
  clearLoginState,
  getLoginStatus,
  isOAuthProvider,
  listOAuthProviders,
  listOAuthProviderDescriptors,
  startLoginFlow,
  upsertOAuthProvider,
} from "../oauth";
import { removeCredential } from "../oauth/store";
import { enrichProviderFromCatalog, listKeyLoginProviders } from "../oauth/key-providers";
import { deriveProviderPresets } from "../providers/derive";
import { fetchProviderQuotaReports } from "../providers/quota";
import { DEFAULT_CONTEXT_CAP_KEY, DEFAULT_PROVIDER_CONTEXT_CAP, contextCapValueRecord, globalContextCapValue, modelContextOverrides, providerContextCap, providerContextCaps, setAllProviderContextCaps, setGlobalContextCapValue, setModelContextOverride, setProviderCapValue, setProviderContextCap } from "../providers/context-cap";
import { readUsageEntries } from "../usage/log";
import { getUsageDebugLogEntries } from "../usage/debug";
import { parseRange, summarizeUsage } from "../usage/summary";
import { stripCodexRuntimeProviderFields } from "../codex/auth-context";
import { getDebugLogEntries } from "../lib/debug-log-buffer";
import {
  clearDebugSettings,
  clearDebugSetting,
  getDebugSettings,
  setDebugSettings,
  type DebugFlag,
} from "../lib/debug-settings";
import type { OcxConfig, OcxProviderConfig } from "../types";
import { drainAndShutdown } from "./lifecycle";
import { filterRequestLogs, getRequestLogEntries } from "./request-log";
import { isAllowedRequestOrigin, jsonResponse, providerManagementConfigError, publicProviderBaseUrl, safeConfigDTO } from "./auth-cors";

import { markActivity } from "../lib/sidecar-tracker";
// Single source of truth = package.json (../ from src/), so /healthz + the GUI badge match the
// installed npm version instead of a stale hardcode.
export const VERSION = (() => {
  try {
    return JSON.parse(readFileSync(new URL("../../package.json", import.meta.url), "utf8")).version as string;
  } catch {
    return "0.0.0";
  }
})();

function parseDebugLogQuery(url: URL): { after: number; limit: number } {
  const after = Number(url.searchParams.get("after") ?? url.searchParams.get("since") ?? "0");
  const limit = Number(url.searchParams.get("limit") ?? "500");
  return {
    after: Number.isFinite(after) && after > 0 ? after : 0,
    limit: Number.isFinite(limit) && limit > 0 ? Math.min(limit, 2000) : 500,
  };
}

export async function handleManagementAPI(req: Request, url: URL, config: OcxConfig, sourceIp: string | null = null): Promise<Response | null> {
  if (!isAllowedRequestOrigin(req, config)) {
    return jsonResponse({ error: "cross-origin request blocked" }, 403, req, config);
  }
  // Management bodies are small JSON (provider names, key ids, settings). Reject oversized
  // payloads before any handler buffers them — the data plane has its own decompression cap.
  if (req.method === "POST" || req.method === "PUT") {
    const contentLength = Number(req.headers.get("content-length") ?? "0");
    if (Number.isFinite(contentLength) && contentLength > 2 * 1024 * 1024) {
      return jsonResponse({ error: "request body too large" }, 413, req, config);
    }
  }
  // Fire-and-forget: the on-disk catalog refresh must NEVER block a management API
  // response. A slow or unreachable upstream (DNS hiccup, broken provider URL) used to
  // hang DELETE / POST / PATCH for up to the AbortSignal timeout because callers awaited
  // this. The catalog is just a sync hint for Codex's next poll -- it is not part of
  // the operation's contract. The inner try/catch keeps the returned promise resolved,
  // so callers can fire it without await and there are no unhandled-rejection warnings.
  async function refreshCodexCatalogBestEffort(): Promise<void> {
    try {
      const { refreshCodexModelCatalog } = await import("../codex/refresh");
      await refreshCodexModelCatalog(config);
    } catch {
      /* catalog absent */
    }
  }

  if (url.pathname === "/api/config" && req.method === "GET") {
    return jsonResponse(safeConfigDTO(config));
  }

  if (url.pathname === "/api/config" && req.method === "PUT") {
    return jsonResponse({ error: "Full config PUT is disabled. Use /api/providers POST for provider changes." }, 405);
  }

  if (url.pathname === "/api/settings" && req.method === "GET") {
    return jsonResponse({
      codexAutoStart: codexAutoStartEnabled(config),
      port: config.port,
      hostname: config.hostname ?? "127.0.0.1",
    });
  }

  if (url.pathname === "/api/settings" && req.method === "PUT") {
    let body: { codexAutoStart?: unknown };
    try { body = await req.json(); } catch { return jsonResponse({ error: "invalid JSON body" }, 400); }
    if (typeof body.codexAutoStart !== "boolean") {
      return jsonResponse({ error: "codexAutoStart boolean is required" }, 400);
    }
    config.codexAutoStart = body.codexAutoStart;
    saveConfig(config);
    return jsonResponse({ ok: true, codexAutoStart: codexAutoStartEnabled(config) });
  }

  // Phase 5: opencodex-only launcher-mode settings. Read returns the current effective values;
  // write returns updated values. The endpoint never exposes providers / api keys / headers /
  // cookie tokens — only the four launcher-related fields. Default values are mirrored back
  // so the GUI can render switches in their effective state.
  if (url.pathname === "/api/opencodex/config" && req.method === "GET") {
    return jsonResponse({
      enableCodexLauncherMode: config.enableCodexLauncherMode !== false,
      syncRoutedModels: config.syncRoutedModels !== false,
      syncNativeOpenaiModels: config.syncNativeOpenaiModels !== false,
      preset: config.preset ?? null,
    });
  }

  if (url.pathname === "/api/opencodex/config" && req.method === "PUT") {
    let body: {
      enableCodexLauncherMode?: unknown;
      syncRoutedModels?: unknown;
      syncNativeOpenaiModels?: unknown;
      preset?: unknown;
    };
    try { body = await req.json(); } catch { return jsonResponse({ error: "invalid JSON body" }, 400); }
    const ALLOWED_PRESETS = new Set(["launcher", "proxy-only", "full-pass-through"]);
    const updates: Partial<typeof config> = {};
    let conflictReason: string | null = null;
    const presetProvided = body.preset !== undefined && body.preset !== null;
    const boolProvided = body.enableCodexLauncherMode !== undefined
      || body.syncRoutedModels !== undefined
      || body.syncNativeOpenaiModels !== undefined;
    if (presetProvided) {
      if (typeof body.preset !== "string" || !ALLOWED_PRESETS.has(body.preset)) {
        return jsonResponse({ error: "preset must be one of: launcher, proxy-only, full-pass-through (or null to clear)" }, 400);
      }
      if (boolProvided) {
        conflictReason = "preset must not be combined with the three boolean fields; pick one shape";
      } else {
        updates.preset = body.preset as "launcher" | "proxy-only" | "full-pass-through";
      }
    }
    if (!conflictReason) {
      for (const [k, raw] of [
        ["enableCodexLauncherMode", body.enableCodexLauncherMode],
        ["syncRoutedModels", body.syncRoutedModels],
        ["syncNativeOpenaiModels", body.syncNativeOpenaiModels],
      ] as const) {
        if (raw === undefined) continue;
        if (typeof raw !== "boolean") {
          conflictReason = `${k} must be a boolean`;
          break;
        }
        (updates as Record<string, unknown>)[k] = raw;
      }
    }
    if (conflictReason) {
      return jsonResponse({ error: conflictReason }, 400);
    }
    // Apply atomically. saveConfig uses atomicWriteFile under the hood.
    Object.assign(config, updates);
    saveConfig(config);
    return jsonResponse({
      ok: true,
      enableCodexLauncherMode: config.enableCodexLauncherMode !== false,
      syncRoutedModels: config.syncRoutedModels !== false,
      syncNativeOpenaiModels: config.syncNativeOpenaiModels !== false,
      preset: config.preset ?? null,
    });
  }

  // Phase-7: POST /api/proxy/restart — spawns detached `ocx restart` subprocess,
  // returns immediately with {ok, initiated, pid}. The child does handleStop + handleEnsure;
  // by the time it actually kills the proxy, this response has already been flushed.
  // Falls back gracefully if Bun spawn fails (we keep the current proxy up and surface the error).
  if (url.pathname === "/api/proxy/restart" && req.method === "POST") {
    try {
      const { spawn } = await import("node:child_process");
      const { fileURLToPath } = await import("node:url");
      const { dirname, resolve } = await import("node:path");
      const here = dirname(fileURLToPath(import.meta.url));
      const projectRoot = resolve(here, "../..");
      const spawnOpts: Record<string, unknown> = {
        cwd: projectRoot,
        detached: true,
        stdio: "ignore" as const,
        env: process.env,
      };
      if (process.platform === "win32") {
        spawnOpts.windowsHide = true;
      }
      // Tiny grace delay so the parent proxy flushes this response before the child stops it.
      const child = spawn("bun", ["run", "src/cli/index.ts", "restart"], spawnOpts);
      child.unref();
      return jsonResponse({
        ok: true,
        initiated: true,
        pid: child.pid,
        note: "Restart scheduled; this proxy will stop momentarily. The GUI will reconnect after the new instance comes up on the same port.",
      });
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      return jsonResponse({ ok: false, error: `failed to spawn restart: ${msg}` }, 500);
    }
  }

  if (url.pathname === "/api/diagnostics/project-config" && req.method === "GET") {
    const { getCachedProjectConfigDiagnostics } = await import("../codex/project-config-warnings");
    const { warnings, grouped } = getCachedProjectConfigDiagnostics();
    return jsonResponse({ warnings, grouped });
  }

  if (url.pathname === "/api/sync" && req.method === "POST") {
    const { syncModelsToCodex } = await import("../codex/sync");
    const result = await syncModelsToCodex(undefined, config, null);
    return jsonResponse({
      ...result,
      staleAppServerHint: "If Codex App still shows an older model list, restart its long-lived app-server process after sync.",
    }, result.ok ? 200 : 500);
  }

  if (url.pathname === "/api/update/check" && req.method === "GET") {
    const { checkForUpdate, normalizeUpdateChannel } = await import("../update/job");
    const rawTag = url.searchParams.get("tag");
    if (rawTag && rawTag !== "latest" && rawTag !== "preview") {
      return jsonResponse({ error: "tag must be latest or preview" }, 400);
    }
    return jsonResponse(checkForUpdate(normalizeUpdateChannel(rawTag)));
  }

  if (url.pathname === "/api/update/run" && req.method === "POST") {
    const { normalizeUpdateChannel, startUpdateJob, UpdateJobError } = await import("../update/job");
    let body: { tag?: unknown; restart?: unknown };
    try { body = await req.json(); } catch { return jsonResponse({ error: "invalid JSON body" }, 400); }
    if (body.tag !== undefined && body.tag !== "latest" && body.tag !== "preview") {
      return jsonResponse({ error: "tag must be latest or preview" }, 400);
    }
    if (body.restart !== undefined && typeof body.restart !== "boolean") {
      return jsonResponse({ error: "restart boolean is required" }, 400);
    }
    try {
      return jsonResponse({ ok: true, job: startUpdateJob(normalizeUpdateChannel(body.tag as string | undefined), body.restart !== false) });
    } catch (err) {
      if (err instanceof UpdateJobError) {
        return jsonResponse({ error: err.message, code: err.code }, err.status);
      }
      return jsonResponse({ error: err instanceof Error ? err.message : String(err) }, 500);
    }
  }

  if (url.pathname === "/api/update/status" && req.method === "GET") {
    const { readUpdateJob } = await import("../update/job");
    const job = readUpdateJob(url.searchParams.get("jobId"));
    if (!job) return jsonResponse({ error: "update job not found" }, 404);
    return jsonResponse({ ok: true, job });
  }

  if (url.pathname === "/api/sidecar-settings" && req.method === "GET") {
    const ws = config.webSearchSidecar ?? {};
    const vs = config.visionSidecar ?? {};
    return jsonResponse({
      webSearch: { model: ws.model ?? "gpt-5.6-luna", reasoning: ws.reasoning ?? "low" },
      vision: { model: vs.model ?? "gpt-5.6-luna" },
    });
  }

  if (url.pathname === "/api/sidecar-settings" && req.method === "PUT") {
    let body: { webSearch?: { model?: string; reasoning?: string }; vision?: { model?: string } };
    try { body = await req.json(); } catch { return jsonResponse({ error: "invalid JSON body" }, 400); }
    if (body.webSearch) {
      config.webSearchSidecar = { ...config.webSearchSidecar };
      if (typeof body.webSearch.model === "string") config.webSearchSidecar.model = body.webSearch.model;
      if (typeof body.webSearch.reasoning === "string") config.webSearchSidecar.reasoning = body.webSearch.reasoning;
    }
    if (body.vision) {
      config.visionSidecar = { ...config.visionSidecar };
      if (typeof body.vision.model === "string") config.visionSidecar.model = body.vision.model;
    }
    saveConfig(config);
    const ws = config.webSearchSidecar ?? {};
    const vs = config.visionSidecar ?? {};
    return jsonResponse({
      ok: true,
      webSearch: { model: ws.model ?? "gpt-5.6-luna", reasoning: ws.reasoning ?? "low" },
      vision: { model: vs.model ?? "gpt-5.6-luna" },
    });
  }

  if (url.pathname === "/api/logs" && req.method === "GET") {
    return jsonResponse(filterRequestLogs(getRequestLogEntries(), url.searchParams));
  }

  if (url.pathname === "/api/debug" && req.method === "GET") {
    return jsonResponse(getDebugSettings());
  }

  if (url.pathname === "/api/debug/logs" && req.method === "GET") {
    const { after, limit } = parseDebugLogQuery(url);
    return jsonResponse(getDebugLogEntries({ after, limit }));
  }

  if (url.pathname === "/api/debug/usage-logs" && req.method === "GET") {
    const { after, limit } = parseDebugLogQuery(url);
    return jsonResponse(getUsageDebugLogEntries({ after, limit }));
  }

  if (url.pathname === "/api/debug" && req.method === "PUT") {
    let body: { debug?: unknown; usage?: unknown; injection?: unknown; reset?: unknown };
    try { body = await req.json(); } catch { return jsonResponse({ error: "invalid JSON body" }, 400); }
    if (body.reset === true) return jsonResponse(clearDebugSettings());
    if (body.reset === "debug" || body.reset === "provider") return jsonResponse(clearDebugSetting("debug"));
    if (body.reset === "usage") return jsonResponse(clearDebugSetting("usage"));
    if (body.reset === "injection") return jsonResponse(clearDebugSetting("injection"));
    const partial: Partial<Record<DebugFlag, boolean>> = {};
    for (const key of ["debug", "usage", "injection"] as const) {
      if (body[key] === undefined) continue;
      if (typeof body[key] !== "boolean") return jsonResponse({ error: `${key} must be a boolean` }, 400);
      partial[key] = body[key];
    }
    if (Object.keys(partial).length === 0) {
      return jsonResponse({ error: "provide debug/usage/injection booleans or reset:true" }, 400);
    }
    return jsonResponse(setDebugSettings(partial));
  }

  if (url.pathname === "/api/usage" && req.method === "GET") {
    const range = parseRange(url.searchParams.get("range"));
    const now = Date.now();
    try {
      return jsonResponse(summarizeUsage(readUsageEntries(), range, now));
    } catch {
      return jsonResponse({
        range,
        since: null,
        generatedAt: now,
        summary: {
          requests: 0,
          measuredRequests: 0,
          reportedRequests: 0,
          unreportedRequests: 0,
          unsupportedRequests: 0,
          estimatedRequests: 0,
          inputTokens: 0,
          outputTokens: 0,
          cachedInputTokens: 0,
          reasoningOutputTokens: 0,
          totalTokens: 0,
          coverageRatio: 0,
        },
        days: [],
        models: [],
        providers: [],
        error: "read_failed",
      });
    }
  }

  if (url.pathname === "/api/provider-quotas" && req.method === "GET") {
    const forceRefresh = url.searchParams.get("refresh") === "1" || url.searchParams.get("refresh") === "true";
    return jsonResponse(await fetchProviderQuotaReports(config, forceRefresh));
  }

  if (url.pathname === "/api/providers" && req.method === "GET") {
    return jsonResponse(Object.entries(config.providers).map(([name, p]) => ({
      name, adapter: p.adapter, baseUrl: publicProviderBaseUrl(p.baseUrl), defaultModel: p.defaultModel,
      testModel: p.testModel,
      modelCount: Array.isArray(p.models) ? p.models.length : 0,
      hasApiKey: !!p.apiKey,
      disabled: p.disabled === true,
    })));
  }

  // Add (or overwrite) a single provider. Merges into the live in-memory config and
  // persists — existing providers' real keys are never round-tripped (unlike PUT /api/config,
  // which would re-save the masked keys from GET). Live routing picks it up immediately.
  if (url.pathname === "/api/providers" && req.method === "POST") {
    let body: { name?: string; provider?: OcxProviderConfig; setDefault?: boolean };
    try { body = await req.json(); } catch { return jsonResponse({ error: "invalid JSON body" }, 400); }
    const name = body.name?.trim();
    const prov = body.provider ? stripCodexRuntimeProviderFields(body.provider) : undefined;
    if (!name || !prov?.adapter || !prov?.baseUrl) {
      return jsonResponse({ error: "name, provider.adapter and provider.baseUrl are required" }, 400);
    }
    if (!isValidProviderName(name)) {
      return jsonResponse({ error: "provider name must use letters, numbers, dot, underscore, or hyphen and cannot be a reserved object key" }, 400);
    }
    const providerError = providerManagementConfigError(name, prov);
    if (providerError) return jsonResponse({ error: providerError }, 400);
    // Catalog providers (e.g. ollama-cloud) carry a models + vision/reasoning classification the GUI
    // doesn't send — merge it in so the sidecars are gated correctly.
    enrichProviderFromCatalog(name, prov);
    const { saveConfig: save } = await import("../config");
    // Overwriting an existing provider must not drop its multi-key pool: carry it over, then
    // let the (possibly new) apiKey join the pool as the active entry.
    const existingPool = config.providers[name]?.apiKeyPool;
    if (existingPool && !prov.apiKeyPool) prov.apiKeyPool = existingPool;
    config.providers[name] = prov;
    if (body.setDefault) config.defaultProvider = name;
    save(config);
    if (prov.apiKey && prov.apiKeyPool) {
      const { addProviderApiKey } = await import("../providers/api-keys");
      addProviderApiKey(config, name, prov.apiKey);
    }
    const { clearModelCache } = await import("../codex/model-cache");
    clearModelCache(name);
    refreshCodexCatalogBestEffort();
    return jsonResponse({ success: true, name });
  }

  if (url.pathname === "/api/providers" && req.method === "PATCH") {
    const name = url.searchParams.get("name")?.trim();
    if (!name || !isValidProviderName(name) || !hasOwnProvider(config.providers, name)) return jsonResponse({ error: "unknown provider" }, 404);
    let body: { disabled?: unknown; setDefault?: unknown };
    try { body = await req.json(); } catch { return jsonResponse({ error: "invalid JSON body" }, 400); }
    const wantDisabled = typeof body.disabled === "boolean" ? body.disabled : undefined;
    const wantSetDefault = body.setDefault === true;
    if (wantDisabled === undefined && !wantSetDefault) return jsonResponse({ error: "at least one of `disabled` or `setDefault` is required" }, 400);
    if (body.disabled && name === config.defaultProvider) {
      return jsonResponse({ error: "cannot disable the default provider; set another default first" }, 400);
    }
    // setDefault=true means "make this provider the new default". Previously only POST /api/providers
    // supported this (for newly added providers); extending PATCH lets the GUI switch default on
    // an existing provider without the add/remove round-trip.
    if (wantSetDefault) {
      config.defaultProvider = name;
    }
    const { saveConfig: save } = await import("../config");
    if (wantDisabled !== undefined) {
      config.providers[name] = { ...config.providers[name], disabled: wantDisabled };
    }
    save(config);
    refreshCodexCatalogBestEffort();
    return jsonResponse({ success: true, name, disabled: wantDisabled, defaultProvider: config.defaultProvider });
  }

  if (url.pathname === "/api/providers" && req.method === "DELETE") {
    const name = url.searchParams.get("name")?.trim();
    if (!name || !isValidProviderName(name) || !hasOwnProvider(config.providers, name)) return jsonResponse({ error: "unknown provider" }, 404);
    if (name === config.defaultProvider) return jsonResponse({ error: "cannot delete the default provider; set another default first" }, 400);
    const { saveConfig: save } = await import("../config");
    delete config.providers[name];
    setProviderContextCap(config, name, false);
    save(config);
    const { clearModelCache: clearCache } = await import("../codex/model-cache");
    clearCache(name);
    refreshCodexCatalogBestEffort();
    return jsonResponse({ success: true });
  }

  if (url.pathname === "/api/models" && req.method === "GET") {
    const models = await fetchAllModels(config);
    const disabled = new Set(config.disabledModels ?? []);
    // Per-model context-cap override map (number = hard cap, false = opt-out of provider cap).
    // Surfaced on each routed row so the GUI Models page can render a per-row Select without
    // joining with /api/provider-context-caps. Native rows have no override (provider cap never
    // applies to the openai passthrough).
    const overrides = modelContextOverrides(config);
    // Native GPT passthrough rows lead (provider "openai", bare-slug namespaced ids): sourced
    // from the static supported set so a disabled model stays listed and re-enableable.
    const native = nativeModelRows(config).map(row => ({
      provider: "openai",
      id: row.slug,
      namespaced: row.slug,
      disabled: row.disabled,
      native: true,
      ...(row.contextWindow !== undefined ? { contextWindow: row.contextWindow } : {}),
    }));
    return jsonResponse([...native, ...models.map(m => {
      const namespaced = `${m.provider}/${m.id}`;
      const contextCap = providerContextCap(config, m.provider);
      const override = overrides[namespaced];
      return {
        ...m,
        namespaced,
        disabled: disabled.has(namespaced),
        ...(contextCap !== undefined ? { contextCap, contextCapped: m.contextCapped === true } : {}),
        ...(override !== undefined ? { modelOverride: override } : {}),
      };
    })]);
  }

  if (url.pathname === "/api/provider-context-caps" && req.method === "GET") {
    const record = contextCapValueRecord(config.contextCapValue);
    return jsonResponse({
      cap: DEFAULT_PROVIDER_CONTEXT_CAP,
      value: record[DEFAULT_CONTEXT_CAP_KEY] ?? DEFAULT_PROVIDER_CONTEXT_CAP,
      values: record,
      caps: providerContextCaps(config),
      modelOverrides: modelContextOverrides(config),
    });
  }

  if (url.pathname === "/api/provider-context-caps" && req.method === "PUT") {
    let body: { provider?: unknown; enabled?: unknown; value?: unknown; setAll?: unknown; providerValue?: unknown; modelOverrides?: unknown };
    try { body = await req.json(); } catch { return jsonResponse({ error: "invalid JSON body" }, 400); }
    const { saveConfig: save } = await import("../config");
    const { clearModelCache } = await import("../codex/model-cache");
    const respond = () => {
      const record = contextCapValueRecord(config.contextCapValue);
      return jsonResponse({
        ok: true,
        cap: DEFAULT_PROVIDER_CONTEXT_CAP,
        value: record[DEFAULT_CONTEXT_CAP_KEY] ?? DEFAULT_PROVIDER_CONTEXT_CAP,
        values: record,
        caps: providerContextCaps(config),
        modelOverrides: modelContextOverrides(config),
      });
    };

    // Branch 1: set the global cap value and re-point every enabled provider to it.
    if (body.value !== undefined) {
      if (typeof body.value !== "number" || !Number.isFinite(body.value) || body.value <= 0) {
        return jsonResponse({ error: "value must be a positive number" }, 400);
      }
      const affected = Object.keys(providerContextCaps(config));
      setGlobalContextCapValue(config, body.value);
      save(config);
      for (const provider of affected) clearModelCache(provider);
      refreshCodexCatalogBestEffort();
      return respond();
    }

    // Branch 2: enable/clear the cap for every provider at once.
    if (body.setAll !== undefined) {
      if (typeof body.setAll !== "boolean") {
        return jsonResponse({ error: "setAll must be a boolean" }, 400);
      }
      const before = Object.keys(providerContextCaps(config));
      const names = Object.keys(config.providers);
      setAllProviderContextCaps(config, names, body.setAll);
      save(config);
      for (const provider of new Set([...before, ...names])) clearModelCache(provider);
      refreshCodexCatalogBestEffort();
      return respond();
    }

    // Branch 3: per-model cap override (number sets cap, false opts out, null clears).
    if (body.modelOverrides !== undefined) {
      if (!body.modelOverrides || typeof body.modelOverrides !== "object" || Array.isArray(body.modelOverrides)) {
        return jsonResponse({ error: "modelOverrides must be an object" }, 400);
      }
      const affected = new Set<string>();
      for (const [rawModelId, raw] of Object.entries(body.modelOverrides as Record<string, unknown>)) {
        const modelId = rawModelId.trim();
        if (!modelId) return jsonResponse({ error: "modelOverrides key must be a non-empty namespaced model id" }, 400);
        if (raw === null) {
          setModelContextOverride(config, modelId, null);
        } else if (raw === false) {
          setModelContextOverride(config, modelId, false);
        } else if (typeof raw === "number" && Number.isFinite(raw) && raw > 0) {
          setModelContextOverride(config, modelId, Math.floor(raw));
        } else {
          return jsonResponse({ error: `modelOverrides["${modelId}"] must be a positive number, false, or null` }, 400);
        }
        const slash = modelId.indexOf("/");
        if (slash > 0) affected.add(modelId.slice(0, slash));
      }
      save(config);
      for (const provider of affected) clearModelCache(provider);
      refreshCodexCatalogBestEffort();
      return respond();
    }

    // Branch 4: per-provider cap value (write to contextCapValue[provider]).
    if (body.providerValue !== undefined) {
      if (typeof body.provider !== "string") {
        return jsonResponse({ error: "provider string is required with providerValue" }, 400);
      }
      const provider = body.provider.trim();
      if (!isValidProviderName(provider)) {
        return jsonResponse({ error: "provider name must use letters, numbers, dot, underscore, or hyphen and cannot be a reserved object key" }, 400);
      }
      if (!hasOwnProvider(config.providers, provider)) {
        return jsonResponse({ error: "unknown provider" }, 404);
      }
      if (body.providerValue === null) {
        setProviderCapValue(config, provider, null);
      } else if (typeof body.providerValue !== "number" || !Number.isFinite(body.providerValue) || body.providerValue <= 0) {
        return jsonResponse({ error: "providerValue must be a positive number or null" }, 400);
      } else {
        setProviderCapValue(config, provider, body.providerValue);
      }
      save(config);
      clearModelCache(provider);
      refreshCodexCatalogBestEffort();
      return respond();
    }

    // Branch 5: existing per-provider toggle (enable writes the current global value).
    if (typeof body.provider !== "string" || typeof body.enabled !== "boolean") {
      return jsonResponse({ error: "provider string and enabled boolean are required" }, 400);
    }
    const provider = body.provider.trim();
    if (!isValidProviderName(provider)) {
      return jsonResponse({ error: "provider name must use letters, numbers, dot, underscore, or hyphen and cannot be a reserved object key" }, 400);
    }
    if (!hasOwnProvider(config.providers, provider)) {
      return jsonResponse({ error: "unknown provider" }, 404);
    }
    setProviderContextCap(config, provider, body.enabled);
    save(config);
    clearModelCache(provider);
    refreshCodexCatalogBestEffort();
    return respond();
  }

  // Enable/disable models: which routed models Codex sees. PUT hides them from the catalog +
  // /v1/models and invalidates Codex's 5-min models cache so it applies on the next turn.
  if (url.pathname === "/api/disabled-models" && req.method === "PUT") {
    let body: { models?: unknown };
    try { body = await req.json(); } catch { return jsonResponse({ error: "invalid JSON body" }, 400); }
    const disabled = Array.isArray(body.models) ? body.models.filter((m): m is string => typeof m === "string") : [];
    config.disabledModels = disabled;
    const { saveConfig: save } = await import("../config");
    save(config);
    refreshCodexCatalogBestEffort();
    return jsonResponse({ ok: true, disabled });
  }

  // multi_agent_v2 surface toggle. GET reports the flag + the agents.max_threads
  // boot conflict; PUT flips it via the official `codex features` CLI and RESYNCS
  // the catalog so multi-agent surface metadata stays fresh. The catalog build
  // itself never writes config — this endpoint is the only server-side mutation
  // surface for the flag.
  if (url.pathname === "/api/v2" && req.method === "GET") {
    const { isMultiAgentV2Enabled, hasAgentsMaxThreads, getMaxConcurrentThreads } = await import("../codex/features");
    return jsonResponse({
      enabled: isMultiAgentV2Enabled(),
      agentsMaxThreadsConflict: hasAgentsMaxThreads(),
      maxConcurrentThreadsPerSession: getMaxConcurrentThreads(),
      multiAgentMode: config.multiAgentMode ?? "default",
    });
  }
  if (url.pathname === "/api/v2" && req.method === "PUT") {
    let body: { enabled?: unknown; maxConcurrentThreadsPerSession?: unknown; multiAgentMode?: unknown };
    try { body = await req.json(); } catch { return jsonResponse({ error: "invalid JSON body" }, 400); }
    const wantsFlag = body.enabled !== undefined;
    const wantsThreads = body.maxConcurrentThreadsPerSession !== undefined;
    const wantsMode = body.multiAgentMode !== undefined;
    if (!wantsFlag && !wantsThreads && !wantsMode) return jsonResponse({ error: "body must set enabled, multiAgentMode, and/or maxConcurrentThreadsPerSession" }, 400);
    if (wantsFlag && typeof body.enabled !== "boolean") return jsonResponse({ error: "body.enabled must be a boolean" }, 400);
    if (wantsMode && body.multiAgentMode !== "v1" && body.multiAgentMode !== "default" && body.multiAgentMode !== "v2") {
      return jsonResponse({ error: "body.multiAgentMode must be 'v1', 'default', or 'v2'" }, 400);
    }
    if (wantsThreads && (typeof body.maxConcurrentThreadsPerSession !== "number" || !Number.isInteger(body.maxConcurrentThreadsPerSession) || body.maxConcurrentThreadsPerSession < 1)) {
      return jsonResponse({ error: "body.maxConcurrentThreadsPerSession must be an integer >= 1" }, 400);
    }
    const { isMultiAgentV2Enabled, hasAgentsMaxThreads, getMaxConcurrentThreads, setMaxConcurrentThreads } = await import("../codex/features");
    const warnings: string[] = [];
    if (wantsFlag && isMultiAgentV2Enabled() !== body.enabled) {
      const { execFileSync } = await import("node:child_process");
      const command = process.env.CODEX_CLI_PATH?.trim() || "codex";
      try {
        execFileSync(command, ["features", body.enabled ? "enable" : "disable", "multi_agent_v2"],
          { stdio: ["ignore", "pipe", "pipe"], timeout: 15_000, windowsHide: true });
      } catch (err) {
        return jsonResponse({ error: `codex features ${body.enabled ? "enable" : "disable"} failed: ${err instanceof Error ? err.message : String(err)}` }, 502);
      }
      refreshCodexCatalogBestEffort();
    }
    if (wantsThreads) {
      // setMaxConcurrentThreads is idempotent (equal value -> no write) and refuses
      // when the [features.multi_agent_v2] table is missing, so a threads-only PUT
      // against a never-enabled config fails loudly instead of inventing state.
      const result = setMaxConcurrentThreads(body.maxConcurrentThreadsPerSession as number);
      if (!result.ok) return jsonResponse({ error: result.error }, 409);
      if (result.changed) warnings.push("Thread limit applies to new sessions.");
    }
    if (wantsMode) {
      const mode = body.multiAgentMode as "v1" | "default" | "v2";
      if (mode === "default") delete config.multiAgentMode;
      else config.multiAgentMode = mode;
      saveConfig(config);
      refreshCodexCatalogBestEffort();
      warnings.push(`Multi-agent mode set to '${mode}'. Applies to new sessions.`);
    }
    if ((wantsFlag ? body.enabled === true : isMultiAgentV2Enabled()) && hasAgentsMaxThreads()) {
      warnings.push("[agents] max_threads is set — codex refuses to start while multi_agent_v2 is enabled; remove it (features.multi_agent_v2.max_concurrent_threads_per_session replaces it).");
    }
    if (wantsFlag) warnings.push("Applies to new sessions; restart the Codex app or wait out its picker cache to see the ladder change.");
    return jsonResponse({
      ok: true,
      enabled: isMultiAgentV2Enabled(),
      maxConcurrentThreadsPerSession: getMaxConcurrentThreads(),
      multiAgentMode: config.multiAgentMode ?? "default",
      warnings,
    });
  }

  // Which providers support real OAuth login (drives the GUI's "Log in with …" buttons).
  if (url.pathname === "/api/oauth/providers" && req.method === "GET") {
    return jsonResponse({ providers: listOAuthProviderDescriptors() });
  }

  // API-key "login" providers (open dashboard → paste key). Drives the GUI's key-provider picker.
  if (url.pathname === "/api/key-providers" && req.method === "GET") {
    return jsonResponse({ providers: listKeyLoginProviders() });
  }

  // Complete GUI picker presets, derived from the canonical provider registry. The GUI is a
  // standalone Vite package, so it consumes this runtime view instead of importing repo-root src.
  if (url.pathname === "/api/provider-presets" && req.method === "GET") {
    return jsonResponse({ providers: deriveProviderPresets() });
  }

  // Subagent prompt injection model: single native or routed model whose info is
  // dynamically injected into the v1 proactive prompt, plus an optional reasoning
  // effort the prompt tells the agent to pass to spawn_agent. GET returns the current
  // picks + available models/efforts; PUT sets or clears them.
  if (url.pathname === "/api/injection-model" && req.method === "GET") {
    const models = await fetchAllModels(config);
    const disabled = new Set(config.disabledModels ?? []);
    const { listCatalogNativeSlugs } = await import("../codex/catalog");
    const { CODEX_REASONING_LEVELS } = await import("../reasoning-effort");
    const nativeModels = listCatalogNativeSlugs()
      .filter(slug => !disabled.has(slug))
      .map(slug => ({ provider: "openai", model: slug, namespaced: slug }));
    const routedModels = models
      .map(m => ({ provider: m.provider, model: m.id, namespaced: `${m.provider}/${m.id}` }))
      .filter(m => !disabled.has(m.namespaced));
    return jsonResponse({
      model: config.injectionModel ?? null,
      effort: config.injectionEffort ?? null,
      prompt: config.injectionPrompt ?? null,
      efforts: CODEX_REASONING_LEVELS.map(l => l.effort),
      available: [...nativeModels, ...routedModels],
    });
  }
  if (url.pathname === "/api/injection-model" && req.method === "PUT") {
    let body: { model?: unknown; effort?: unknown; prompt?: unknown };
    try { body = await req.json(); } catch { return jsonResponse({ error: "invalid JSON body" }, 400); }
    const { isCodexReasoningEffort } = await import("../reasoning-effort");
    const model = typeof body.model === "string" && body.model.length > 0 ? body.model : undefined;
    let effort = config.injectionEffort;
    // `effort` key semantics: absent -> unchanged; null/"" -> clear; ladder value -> set;
    // anything else -> 400. Clearing the model always clears the effort (it is meaningless alone).
    if ("effort" in body) {
      const requestedEffort = typeof body.effort === "string" && body.effort.length > 0 ? body.effort : undefined;
      if (requestedEffort !== undefined && !isCodexReasoningEffort(requestedEffort)) {
        return jsonResponse({ error: `unknown reasoning effort "${requestedEffort}"` }, 400);
      }
      effort = requestedEffort;
    }
    if (!model) effort = undefined;
    if (model) config.injectionModel = model;
    else delete config.injectionModel;
    if (effort) config.injectionEffort = effort;
    else delete config.injectionEffort;
    // `prompt` key semantics mirror `effort`: absent -> unchanged; null/"" -> clear;
    // non-empty string -> set (custom <multi_agent_mode> body, {{model}}/{{effort}}/{{roster}} placeholders).
    if ("prompt" in body) {
      if (typeof body.prompt === "string" && body.prompt.trim().length > 0) config.injectionPrompt = body.prompt;
      else if (body.prompt === null || body.prompt === "") delete config.injectionPrompt;
      else return jsonResponse({ error: "prompt must be a string or null" }, 400);
    }
    saveConfig(config);
    return jsonResponse({ ok: true, model: config.injectionModel ?? null, effort: config.injectionEffort ?? null, prompt: config.injectionPrompt ?? null });
  }

  // Hard reasoning-effort caps (devlog/260710_subagent_effort_intercept): a global ceiling and a
  // sub-agent-only ceiling, enforced per-request in handleResponses (src/server/effort-policy.ts).
  // Key semantics per field: absent -> unchanged; null/"" -> clear; ladder value -> set; else 400.
  if (url.pathname === "/api/effort-caps" && req.method === "GET") {
    const { CODEX_REASONING_LEVELS } = await import("../reasoning-effort");
    return jsonResponse({
      effortCap: config.effortCap ?? null,
      subagentEffortCap: config.subagentEffortCap ?? null,
      efforts: CODEX_REASONING_LEVELS.map(l => l.effort),
    });
  }
  if (url.pathname === "/api/effort-caps" && req.method === "PUT") {
    let body: { effortCap?: unknown; subagentEffortCap?: unknown };
    try { body = await req.json(); } catch { return jsonResponse({ error: "invalid JSON body" }, 400); }
    const { isCodexReasoningEffort } = await import("../reasoning-effort");
    for (const key of ["effortCap", "subagentEffortCap"] as const) {
      if (!(key in body)) continue;
      const value = body[key];
      if (value === null || value === "") { delete config[key]; continue; }
      if (typeof value !== "string" || !isCodexReasoningEffort(value)) {
        return jsonResponse({ error: `unknown reasoning effort "${String(value)}"` }, 400);
      }
      config[key] = value;
    }
    saveConfig(config);
    return jsonResponse({ ok: true, effortCap: config.effortCap ?? null, subagentEffortCap: config.subagentEffortCap ?? null });
  }

  // Subagent model picker: which ≤5 routed models Codex's spawn_agent advertises (it shows the
  // first 5 routed catalog entries). PUT reorders the injected catalog so the chosen ones lead.
  if (url.pathname === "/api/subagent-models" && req.method === "GET") {
    const models = await fetchAllModels(config);
    const disabled = new Set(config.disabledModels ?? []);
    // Native gpt (passthrough) are also valid subagent picks — they're picker-visible models in the
    // catalog, just buried by priority. List them first so the user can feature them over routed.
    const { listCatalogNativeSlugs } = await import("../codex/catalog");
    const available = [
      ...listCatalogNativeSlugs(),
      ...models.map(m => `${m.provider}/${m.id}`),
    ].filter(ns => !disabled.has(ns));
    return jsonResponse({ chosen: config.subagentModels ?? [], available });
  }
  if (url.pathname === "/api/subagent-models" && req.method === "PUT") {
    let body: { models?: unknown };
    try { body = await req.json(); } catch { return jsonResponse({ error: "invalid JSON body" }, 400); }
    const chosen = Array.isArray(body.models) ? body.models.filter((m): m is string => typeof m === "string").slice(0, 5) : [];
    config.subagentModels = chosen;
    const { saveConfig: save } = await import("../config");
    save(config);
    refreshCodexCatalogBestEffort();
    return jsonResponse({ ok: true, applied: chosen });
  }

  // Per-provider catalog allowlist (issue #52): when a provider has a non-empty selectedModels list,
  // only those ids ship to Codex's catalog / /v1/models. GET returns the CURRENT selection plus the
  // FULL available set per provider (unfiltered — the picker needs everything to choose from).
  if (url.pathname === "/api/selected-models" && req.method === "GET") {
    const models = await fetchAllModels(config);
    const available: Record<string, string[]> = {};
    for (const m of models) (available[m.provider] ??= []).push(m.id);
    const selected: Record<string, string[]> = {};
    for (const [name, prov] of Object.entries(config.providers)) {
      if (Array.isArray(prov.selectedModels) && prov.selectedModels.length > 0) selected[name] = [...prov.selectedModels];
    }
    return jsonResponse({ selected, available });
  }
  if (url.pathname === "/api/selected-models" && req.method === "PUT") {
    let body: { provider?: unknown; models?: unknown };
    try { body = await req.json(); } catch { return jsonResponse({ error: "invalid JSON body" }, 400); }
    const provider = typeof body.provider === "string" ? body.provider : "";
    if (!provider || !hasOwnProvider(config.providers, provider)) {
      return jsonResponse({ error: "unknown provider" }, provider ? 404 : 400);
    }
    const models = Array.isArray(body.models)
      ? [...new Set(body.models.filter((m): m is string => typeof m === "string"))]
      : [];
    // Empty list clears the allowlist (provider reverts to exposing all models).
    if (models.length > 0) config.providers[provider].selectedModels = models;
    else delete config.providers[provider].selectedModels;
    const { saveConfig: save } = await import("../config");
    save(config);
    refreshCodexCatalogBestEffort();
    return jsonResponse({ ok: true, provider, selected: models });
  }

  // OAuth login (xai now; anthropic/kimi in cycle 2). Starts the flow and returns the auth URL;
  // the provider's loopback callback server (inside this process) captures the redirect in the
  // background, then the credential is persisted. The GUI opens the URL and polls /api/oauth/status.
  if (url.pathname === "/api/oauth/login" && req.method === "POST") {
    const body = await req.json().catch(() => ({})) as { provider?: string; addAccount?: boolean };
    const provider = (body.provider ?? "").trim().toLowerCase();
    if (!isOAuthProvider(provider)) return jsonResponse({ error: "unknown oauth provider" }, 400);
    try {
      // addAccount forces a fresh browser identity (skips local-CLI token import) so a
      // SECOND account can be added instead of re-importing the first one.
      const { url: authUrl, instructions } = await startLoginFlow(provider, body.addAccount ? { forceLogin: true } : undefined);
      upsertOAuthProvider(config, provider); // mutate LIVE config — routing sees it without restart
      if (authUrl) {
        // Open the browser server-side (the proxy runs on the user's machine) — the GUI's
        // window.open is popup-blocked because it runs after an await, not a direct click.
        const { openUrl } = await import("../lib/open-url");
        openUrl(authUrl);
      }
      return jsonResponse({ url: authUrl, instructions });
    } catch (err) {
      return jsonResponse({ error: err instanceof Error ? err.message : String(err) }, 409);
    }
  }

  if (url.pathname === "/api/oauth/status" && req.method === "GET") {
    const provider = (url.searchParams.get("provider") ?? "").trim().toLowerCase();
    return jsonResponse(getLoginStatus(provider));
  }

  if (url.pathname === "/api/oauth/logout" && req.method === "POST") {
    const provider = (url.searchParams.get("provider") ?? "").trim().toLowerCase();
    if (!isOAuthProvider(provider)) return jsonResponse({ error: "unknown oauth provider" }, 400);
    removeCredential(provider);
    clearLoginState(provider);
    return jsonResponse({ success: true });
  }

  // Multiauth account management: list a provider's logged-in accounts, switch the active
  // one, or remove one. Emails are masked; tokens never leave the store.
  if (url.pathname === "/api/oauth/accounts" && req.method === "GET") {
    const provider = (url.searchParams.get("provider") ?? "").trim().toLowerCase();
    if (!isOAuthProvider(provider)) return jsonResponse({ error: "unknown oauth provider" }, 400);
    const status = getLoginStatus(provider);
    return jsonResponse({ activeAccountId: status.activeAccountId ?? null, accounts: status.accounts ?? [] });
  }
  if (url.pathname === "/api/oauth/accounts/active" && req.method === "PUT") {
    const body = await req.json().catch(() => ({})) as { provider?: string; accountId?: string };
    const provider = (body.provider ?? "").trim().toLowerCase();
    if (!isOAuthProvider(provider)) return jsonResponse({ error: "unknown oauth provider" }, 400);
    if (!body.accountId) return jsonResponse({ error: "missing accountId" }, 400);
    const { setActiveAccount } = await import("../oauth/store");
    if (!setActiveAccount(provider, body.accountId)) return jsonResponse({ error: "account not found" }, 404);
    const { clearProviderQuotaCache } = await import("../providers/quota");
    clearProviderQuotaCache();
    return jsonResponse({ ok: true, provider, activeAccountId: body.accountId });
  }
  if (url.pathname === "/api/oauth/accounts" && req.method === "DELETE") {
    const provider = (url.searchParams.get("provider") ?? "").trim().toLowerCase();
    const id = url.searchParams.get("id") ?? "";
    if (!isOAuthProvider(provider)) return jsonResponse({ error: "unknown oauth provider" }, 400);
    if (!id) return jsonResponse({ error: "missing id" }, 400);
    const { removeAccount, getAccountSet } = await import("../oauth/store");
    if (!removeAccount(provider, id)) return jsonResponse({ error: "account not found" }, 404);
    if (!getAccountSet(provider)) clearLoginState(provider);
    const { clearProviderQuotaCache } = await import("../providers/quota");
    clearProviderQuotaCache();
    return jsonResponse({ ok: true });
  }

  // Multi-key pool for API-key providers (same GUI dropdown as OAuth multiauth): list masked
  // keys, add one (upserts + activates), switch the active key, or remove one. `apiKey` always
  // mirrors the active entry so routing is untouched.
  if (url.pathname === "/api/providers/keys" && req.method === "GET") {
    const name = (url.searchParams.get("name") ?? "").trim();
    if (!name || !isValidProviderName(name) || !hasOwnProvider(config.providers, name)) return jsonResponse({ error: "unknown provider" }, 404);
    const { listProviderApiKeys } = await import("../providers/api-keys");
    return jsonResponse(listProviderApiKeys(config, name));
  }
  if (url.pathname === "/api/providers/keys" && req.method === "POST") {
    const body = await req.json().catch(() => ({})) as { name?: string; key?: string; label?: string };
    const name = (body.name ?? "").trim();
    if (!name || !isValidProviderName(name) || !hasOwnProvider(config.providers, name)) return jsonResponse({ error: "unknown provider" }, 404);
    if (typeof body.key !== "string" || !body.key.trim()) return jsonResponse({ error: "key is required" }, 400);
    const { addProviderApiKey } = await import("../providers/api-keys");
    const result = addProviderApiKey(config, name, body.key, body.label);
    if ("error" in result) return jsonResponse({ error: result.error }, 400);
    const { clearModelCache } = await import("../codex/model-cache");
    clearModelCache(name);
    const { clearProviderQuotaCache } = await import("../providers/quota");
    clearProviderQuotaCache();
    const { clearKeyCooldowns } = await import("../providers/key-failover");
    clearKeyCooldowns(name); // manual key management resets 429 cooldown state
    const { clearKeyScheduleState } = await import("../providers/key-scheduler");
    clearKeyScheduleState(name); // manual key management resets scheduler probe/local state
    return jsonResponse({ ok: true, id: result.id }, 201);
  }
  if (url.pathname === "/api/providers/keys/active" && req.method === "PUT") {
    const body = await req.json().catch(() => ({})) as { name?: string; id?: string };
    const name = (body.name ?? "").trim();
    if (!name || !isValidProviderName(name) || !hasOwnProvider(config.providers, name)) return jsonResponse({ error: "unknown provider" }, 404);
    if (!body.id) return jsonResponse({ error: "missing id" }, 400);
    const { setActiveProviderApiKey } = await import("../providers/api-keys");
    if (!setActiveProviderApiKey(config, name, body.id)) return jsonResponse({ error: "key not found" }, 404);
    const { clearModelCache } = await import("../codex/model-cache");
    clearModelCache(name);
    const { clearProviderQuotaCache } = await import("../providers/quota");
    clearProviderQuotaCache();
    const { clearKeyCooldowns } = await import("../providers/key-failover");
    clearKeyCooldowns(name); // manual key management resets 429 cooldown state
    const { clearKeyScheduleState } = await import("../providers/key-scheduler");
    clearKeyScheduleState(name); // manual key management resets scheduler probe/local state
    return jsonResponse({ ok: true, name, activeId: body.id });
  }
  if (url.pathname === "/api/providers/keys" && req.method === "DELETE") {
    const name = (url.searchParams.get("name") ?? "").trim();
    const id = url.searchParams.get("id") ?? "";
    if (!name || !isValidProviderName(name) || !hasOwnProvider(config.providers, name)) return jsonResponse({ error: "unknown provider" }, 404);
    if (!id) return jsonResponse({ error: "missing id" }, 400);
    const { removeProviderApiKey } = await import("../providers/api-keys");
    if (!removeProviderApiKey(config, name, id)) return jsonResponse({ error: "key not found" }, 404);
    const { clearModelCache } = await import("../codex/model-cache");
    clearModelCache(name);
    const { clearProviderQuotaCache } = await import("../providers/quota");
    clearProviderQuotaCache();
    const { clearKeyCooldowns } = await import("../providers/key-failover");
    clearKeyCooldowns(name); // manual key management resets 429 cooldown state
    const { clearKeyScheduleState } = await import("../providers/key-scheduler");
    clearKeyScheduleState(name); // manual key management resets scheduler probe/local state
    return jsonResponse({ ok: true });
  }
  // Reveal the full value of a single pool entry. Mirrors /api/keys/reveal: full key content is
  // returned in the response body but never written to logs/audit — the audit line only names
  // the provider + key id so an operator can tell which entry was exposed.
  if (url.pathname === "/api/providers/keys/reveal" && req.method === "POST") {
    let rb: { name?: string; id?: string };
    try { rb = await req.json() as { name?: string; id?: string }; }
    catch { return jsonResponse({ error: "invalid JSON body" }, 400); }
    const name = (rb.name ?? "").trim();
    const id = (rb.id ?? "").trim();
    if (!name || !isValidProviderName(name) || !hasOwnProvider(config.providers, name)) return jsonResponse({ error: "unknown provider" }, 404);
    if (!id) return jsonResponse({ error: "missing id" }, 400);
    const { revealProviderApiKey } = await import("../providers/api-keys");
    const revealed = revealProviderApiKey(config, name, id);
    if (!revealed) return jsonResponse({ error: "key not found" }, 404);
    const ts = new Date().toISOString();
    const from = sourceIp ?? "unknown";
    console.log(`[opencodex-audit] revealed providerApiKey provider=${name} id=${id} label=${revealed.label ?? ""} from=${from} at=${ts}`);
    markActivity(`revealed providerApiKey provider=${name} id=${id} from=${from}`);
    return jsonResponse({ id: revealed.id, label: revealed.label, masked: revealed.masked, key: revealed.key });
  }
  // Probe a pool entry's key against the provider's upstream. Read-only — does not persist,
  // Quota-aware key scheduler state: threshold, next-up candidate, and recent rotation
  // events for the provider card UI (src/providers/key-scheduler.ts). Read-only.
  if (url.pathname === "/api/providers/key-schedule" && req.method === "GET") {
    const name = (url.searchParams.get("name") ?? "").trim();
    if (!name || !isValidProviderName(name) || !hasOwnProvider(config.providers, name)) return jsonResponse({ error: "unknown provider" }, 404);
    // Warm the probe first so nextUpId is meaningful on a fresh server (page load
    // before any request has run the gate).
    const { warmKeyScheduleProbe, getKeyScheduleState } = await import("../providers/key-scheduler");
    await warmKeyScheduleProbe(config, name);
    const state = getKeyScheduleState(config, name);
    if (!state) return jsonResponse({ error: "unknown provider" }, 404);
    return jsonResponse(state);
  }

  // Probe a pool entry's key against the provider's upstream. Read-only — does not persist,
  // does not rotate the active key, and does not touch cooldowns.
  if (url.pathname === "/api/providers/keys/test" && req.method === "POST") {
    let rb: { name?: string; id?: string };
    try { rb = await req.json() as { name?: string; id?: string }; }
    catch { return jsonResponse({ error: "invalid JSON body" }, 400); }
    const name = (rb.name ?? "").trim();
    const id = (rb.id ?? "").trim();
    if (!name || !isValidProviderName(name) || !hasOwnProvider(config.providers, name)) return jsonResponse({ error: "unknown provider" }, 404);
    if (!id) return jsonResponse({ error: "missing id" }, 400);
    const { testProviderApiKey } = await import("../providers/api-keys");
    const result = await testProviderApiKey(config, name, id);
    if ("error" in result) return jsonResponse({ error: result.error }, result.error === "key not found" ? 404 : 400);
    return jsonResponse(result);
  }

  // Fetch the provider's live model list (or return cached `provider.models`). Used by the
  // Providers-page "拉取模型" button to populate the per-key test-model dropdown. Read-only,
  // does not touch cooldowns, does not rotate the active key, and only refreshes `provider.models`
  // when `?refresh=1` is set so the periodic catalog sync's cache is not churned.
  if (url.pathname === "/api/providers/models" && req.method === "POST") {
    let rb: { name?: string; refresh?: boolean };
    try { rb = await req.json() as { name?: string; refresh?: boolean }; }
    catch { return jsonResponse({ error: "invalid JSON body" }, 400); }
    const name = (rb.name ?? "").trim();
    if (!name || !isValidProviderName(name) || !hasOwnProvider(config.providers, name)) return jsonResponse({ error: "unknown provider" }, 404);
    const refresh = rb.refresh === true;
    const provider = config.providers[name];
    const cached = provider.models;
    if (!refresh && cached && cached.length > 0) {
      return jsonResponse({ models: cached, source: "cached" });
    }
    const pool: Array<{ key: string }> = [];
    if (provider.apiKeyPool && provider.apiKeyPool.length > 0) {
      for (const entry of provider.apiKeyPool) pool.push({ key: entry.key });
    } else if (provider.apiKey) {
      pool.push({ key: provider.apiKey });
    }
    if (pool.length === 0) return jsonResponse({ error: "no keys configured" }, 400);
    const { fetchProviderModels } = await import("../providers/catalog-models");
    const result = await fetchProviderModels(provider, pool);
    if ("error" in result) return jsonResponse({ error: result.error }, 400);
    provider.models = result.models;
    saveConfig(config);
    return jsonResponse({ models: result.models, source: "live" });
  }

  // Persist the user's pick for the per-key test model. Body `{ model: string | null }`.
  // `null` clears the override so the probe falls back to defaultModel / hardcoded default.
  if (url.pathname === "/api/providers/test-model" && req.method === "POST") {
    let rb: { name?: string; model?: string | null };
    try { rb = await req.json() as { name?: string; model?: string | null }; }
    catch { return jsonResponse({ error: "invalid JSON body" }, 400); }
    const name = (rb.name ?? "").trim();
    if (!name || !isValidProviderName(name) || !hasOwnProvider(config.providers, name)) return jsonResponse({ error: "unknown provider" }, 404);
    const provider = config.providers[name];
    const raw = rb.model;
    if (raw === null || raw === "") {
      delete provider.testModel;
    } else {
      if (typeof raw !== "string") return jsonResponse({ error: "model must be a string or null" }, 400);
      provider.testModel = raw;
    }
    saveConfig(config);
    return jsonResponse({ testModel: provider.testModel ?? null });
  }

  // ---------------------------------------------------------------------------
  // API Keys management
  // ---------------------------------------------------------------------------
  if (url.pathname === "/api/keys" && req.method === "GET") {
    const keys = config.apiKeys ?? [];
    return jsonResponse({ keys: keys.map(k => ({ id: k.id, name: k.name, prefix: k.key.slice(0, 8) + "...", createdAt: k.createdAt })), endpoint: `http://${config.hostname ?? "127.0.0.1"}:${config.port ?? 10100}/v1/responses` }, 200, req, config);
  }

  if (url.pathname === "/api/keys" && req.method === "POST") {
    const body = await req.json() as { name?: string };
    const name = (body.name ?? "").trim() || "default";
    // Generate key from provider keys hash + random salt
    const providerKeys = Object.values(config.providers).map(p => p.apiKey ?? "").filter(Boolean).join("|");
    const salt = crypto.randomUUID();
    const hashInput = `${providerKeys}|${salt}|${Date.now()}`;
    const hashBuf = new Bun.CryptoHasher("sha256").update(hashInput).digest();
    const key = "ocx_" + Buffer.from(hashBuf).toString("hex").slice(0, 40);
    const entry = { id: crypto.randomUUID(), name, key, createdAt: new Date().toISOString() };
    config.apiKeys = [...(config.apiKeys ?? []), entry];
    saveConfig(config);
    return jsonResponse({ id: entry.id, name: entry.name, key: entry.key, createdAt: entry.createdAt }, 201, req, config);
  }

  if (url.pathname === "/api/keys" && req.method === "DELETE") {
    const body = await req.json() as { id?: string };
    if (!body.id) return jsonResponse({ error: "id required" }, 400, req, config);
    config.apiKeys = (config.apiKeys ?? []).filter(k => k.id !== body.id);
    saveConfig(config);
    return jsonResponse({ success: true }, 200, req, config);
  }
  if (url.pathname === "/api/keys/reveal" && req.method === "POST") {
    let rb: { id?: string };
    try { rb = await req.json() as { id?: string }; }
    catch { return jsonResponse({ error: "invalid JSON body" }, 400, req, config); }
    const rid = rb.id?.trim();
    if (!rid) return jsonResponse({ error: "id required" }, 400, req, config);
    const entry = (config.apiKeys ?? []).find(k => k.id === rid);
    if (!entry) return jsonResponse({ error: "api key not found" }, 404, req, config);
    // Audit: log who revealed which key. Key NAME is included (admin ops needs to
    // know which human-readable key got exposed); full KEY CONTENT is never logged.
    const ts = new Date().toISOString();
    const from = sourceIp ?? "unknown";
    console.log(`[opencodex-audit] revealed apiKey name=${entry.name} id=${rid} from=${from} at=${ts}`);
    markActivity(`revealed apiKey name=${entry.name} id=${rid} from=${from}`);
    return jsonResponse({ id: entry.id, name: entry.name, key: entry.key }, 200, req, config);
  }

  if (url.pathname === "/api/stop" && req.method === "POST") {
    const { restoreNativeCodex } = await import("../codex/inject");
    const { stopServiceIfInstalled } = await import("../service");
    stopServiceIfInstalled();
    const restore = restoreNativeCodex();
    setTimeout(async () => {
      await drainAndShutdown(undefined, config.shutdownTimeoutMs ?? 5000);
      process.exit(0);
    }, 200);
    return jsonResponse(restore.success
      ? { success: true, message: "Proxy stopping, native Codex restored." }
      : { success: false, message: `Proxy stopping, but native Codex restore failed: ${restore.message}. Run \`ocx restore\`.` });
  }

  if (url.pathname.startsWith("/api/codex-auth/")) {
    const { handleCodexAuthAPI } = await import("../codex/auth-api");
    return handleCodexAuthAPI(req, url, config);
  }

  return null;
}

/**
 * Live routed-provider models for the proxy's /api/* and /v1/models endpoints. Delegates to the
 * canonical, TTL-cached `gatherRoutedModels` (single source of truth) — so the GUI/codex endpoints
 * share the same fetch, the same per-provider cache (dedups Codex's frequent /v1/models polling),
 * and the same stale fallback when a provider blips, instead of a parallel uncached copy.
 */
export async function fetchAllModels(config: OcxConfig): Promise<CatalogModel[]> {
  const { gatherRoutedModels } = await import("../codex/catalog");
  return gatherRoutedModels(config);
}
